# Linear 中文化 LSPosed 模块

目标应用：`app.linear`（扫描基准：Linear 1.99.0）

- 不修改 Linear APK，不改变官方签名。
- 通过 libxposed API 102 在运行时替换已知 UI 英文字符串。
- 优先覆盖 Android Resources，同时补 TextView / Android 文本布局链路，以兼容 Compose 页面。
- 仅做精确词典匹配，不翻译用户自己输入的任意文本。

安装：安装构建出的 APK，在 LSPosed 中启用模块并确认作用域为 Linear，然后强制停止并重新打开 Linear。
