package io.github.zhanfg.linearzh;

import android.content.res.Resources;
import android.text.BoringLayout;
import android.text.StaticLayout;
import android.util.Log;
import android.widget.TextView;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.List;

import io.github.libxposed.api.XposedModule;

public final class ModuleMain extends XposedModule {
    private static final String TAG = "LinearZh";
    private static final String TARGET = "app.linear";

    @Override
    public void onPackageReady(PackageReadyParam param) {
        if (!TARGET.equals(param.getPackageName())) return;
        int count = 0;
        count += hookResourceText();
        count += hookTextView();
        count += hookStaticLayout();
        count += hookBoringLayout();
        log(Log.INFO, TAG, "Linear Chinese hooks installed: " + count);
    }

    private int hookResourceText() {
        int count = 0;
        for (Method method : Resources.class.getDeclaredMethods()) {
            String name = method.getName();
            if (!(name.equals("getText") || name.equals("getString") ||
                    name.equals("getQuantityText") || name.equals("getQuantityString"))) continue;
            try {
                hook(method).intercept(chain -> {
                    Object result = chain.proceed();
                    if (result instanceof String) return Translator.translate((String) result);
                    return result;
                });
                count++;
            } catch (Throwable error) {
                log(Log.WARN, TAG, "Resource hook failed: " + method, error);
            }
        }
        return count;
    }

    private int hookTextView() {
        int count = 0;
        for (Method method : TextView.class.getDeclaredMethods()) {
            if (!method.getName().equals("setText")) continue;
            Class<?>[] types = method.getParameterTypes();
            if (types.length == 0 || !CharSequence.class.isAssignableFrom(types[0])) continue;
            try {
                hook(method).intercept(chain -> {
                    Object[] args = chain.getArgs().toArray();
                    if (args.length > 0 && args[0] instanceof String) {
                        args[0] = Translator.translate((String) args[0]);
                    }
                    return chain.proceed(args);
                });
                count++;
            } catch (Throwable error) {
                log(Log.WARN, TAG, "TextView hook failed: " + method, error);
            }
        }
        return count;
    }

    private int hookStaticLayout() {
        int count = 0;
        try {
            for (Method method : StaticLayout.Builder.class.getDeclaredMethods()) {
                if (!method.getName().equals("obtain") || !Modifier.isStatic(method.getModifiers())) continue;
                Class<?>[] types = method.getParameterTypes();
                if (types.length == 0 || !CharSequence.class.isAssignableFrom(types[0])) continue;
                hook(method).intercept(chain -> {
                    Object[] args = chain.getArgs().toArray();
                    if (args.length > 0 && args[0] instanceof String) {
                        args[0] = Translator.translate((String) args[0]);
                        if (args.length > 2 && args[1] instanceof Integer && args[2] instanceof Integer) {
                            args[1] = 0;
                            args[2] = ((String) args[0]).length();
                        }
                    }
                    return chain.proceed(args);
                });
                count++;
            }
        } catch (Throwable error) {
            log(Log.WARN, TAG, "StaticLayout hook setup failed", error);
        }
        return count;
    }

    private int hookBoringLayout() {
        int count = 0;
        for (Method method : BoringLayout.class.getDeclaredMethods()) {
            if (!method.getName().equals("make") || !Modifier.isStatic(method.getModifiers())) continue;
            Class<?>[] types = method.getParameterTypes();
            if (types.length == 0 || !CharSequence.class.isAssignableFrom(types[0])) continue;
            try {
                hook(method).intercept(chain -> {
                    Object[] args = chain.getArgs().toArray();
                    if (args.length > 0 && args[0] instanceof String) {
                        args[0] = Translator.translate((String) args[0]);
                    }
                    return chain.proceed(args);
                });
                count++;
            } catch (Throwable error) {
                log(Log.WARN, TAG, "BoringLayout hook failed: " + method, error);
            }
        }
        return count;
    }
}
