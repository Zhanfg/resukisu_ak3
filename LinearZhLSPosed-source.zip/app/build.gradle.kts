plugins {
    id("com.android.application")
}

android {
    namespace = "io.github.zhanfg.linearzh"
    compileSdk = 36
    buildToolsVersion = "36.0.0"

    defaultConfig {
        applicationId = "io.github.zhanfg.linearzh"
        minSdk = 27
        targetSdk = 36
        versionCode = 1
        versionName = "0.1.0-linear-1.99"
    }

    buildTypes {
        release { isMinifyEnabled = false }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_21
        targetCompatibility = JavaVersion.VERSION_21
    }

    packaging {
        resources {
            merges += "META-INF/xposed/*"
            excludes += "META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    compileOnly("io.github.libxposed:api:102.0.0")
}
