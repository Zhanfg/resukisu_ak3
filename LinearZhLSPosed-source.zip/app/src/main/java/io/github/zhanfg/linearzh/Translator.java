package io.github.zhanfg.linearzh;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

final class Translator {
    private static final Map<String, String> EXACT = load();

    private Translator() {}

    static String translate(String source) {
        if (source == null || source.isEmpty()) return source;
        String direct = EXACT.get(source);
        if (direct != null) return direct;
        return source;
    }

    private static Map<String, String> load() {
        Map<String, String> map = new HashMap<>();
        try (InputStream in = Translator.class.getResourceAsStream("/translations.tsv")) {
            if (in == null) return Collections.emptyMap();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    if (line.isEmpty() || line.charAt(0) == '#') continue;
                    int tab = line.indexOf('\t');
                    if (tab <= 0 || tab == line.length() - 1) continue;
                    map.put(line.substring(0, tab), line.substring(tab + 1));
                }
            }
        } catch (Throwable ignored) {
            return Collections.emptyMap();
        }
        return Collections.unmodifiableMap(map);
    }
}
